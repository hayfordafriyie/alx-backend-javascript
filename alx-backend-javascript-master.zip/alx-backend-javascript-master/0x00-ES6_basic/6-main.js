import getSanFranciscoDescription from './6-string-interpolation.js';

console.log(getSanFranciscoDescription());
