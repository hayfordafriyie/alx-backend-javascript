export default function getListStudents() {
  const o1 = {
    id: 1,
    firstName: 'Guillaume',
    location: 'San Francisco',
  };

  const o2 = {
    id: 2,
    firstName: 'James',
    location: 'Columbia',
  };

  const o3 = {
    id: 5,
    firstName: 'Serena',
    location: 'San Francisco',
  };

  return [o1, o2, o3];
}
