import getListStudents from "./0-get_list_students.js";

console.log(getListStudents());
