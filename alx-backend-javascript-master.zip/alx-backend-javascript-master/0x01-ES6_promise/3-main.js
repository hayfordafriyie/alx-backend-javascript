import handleProfileSignup from "./3-all";

handleProfileSignup();
