const calculateNumber = (a, b) => Math.round(a) + Math.round(b);

module.exports = calculateNumber;
